package com.farmrpg.jobs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.fluids.capability.IFluidHandler.FluidAction;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.ItemStackHandler;

/** Server-owned storage and atomic crafting for one workbench. */
public final class GuildAlchemyWorkbenchBlockEntity extends BlockEntity {
    public static final int SLOT_COUNT = 6;
    public static final int FIRST_HERB_SLOT = 0;
    public static final int LAST_HERB_SLOT = 2;
    public static final int CATALYST_SLOT = 3;
    public static final int BOTTLE_SLOT = 4;
    public static final int OUTPUT_SLOT = 5;
    public static final int WATER_CAPACITY = 4000;
    private static final String INVENTORY_TAG = "Inventory";
    private static final String WATER_TAG = "WaterAmount";
    private boolean crafting;

    private final ItemStackHandler inventory = new ItemStackHandler(SLOT_COUNT) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isValidInput(slot, stack);
        }

        @Override
        protected void onContentsChanged(int slot) {
            if (!crafting) setChanged();
        }
    };

    private final FluidTank water = new FluidTank(WATER_CAPACITY, stack -> stack.is(Fluids.WATER)) {
        @Override
        protected void onContentsChanged() {
            if (!crafting) publishWaterChange();
        }
    };

    private void publishWaterChange() {
        setChanged();
        if (level != null && !level.isClientSide && !isRemoved() && level.getBlockEntity(worldPosition) == this) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }

    public GuildAlchemyWorkbenchBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GUILD_ALCHEMY_WORKBENCH.get(), pos, state);
    }

    static boolean isValidInput(int slot, ItemStack stack) {
        if (stack.isEmpty()) return false;
        if (slot >= FIRST_HERB_SLOT && slot <= LAST_HERB_SLOT) {
            return stack.getItem() instanceof MoonlightHerbItem;
        }
        if (slot == CATALYST_SLOT) {
            return stack.is(Items.REDSTONE) || stack.is(Items.GLOWSTONE_DUST) || stack.is(Items.BLAZE_POWDER);
        }
        return slot == BOTTLE_SLOT && stack.is(Items.GLASS_BOTTLE);
    }

    // Package-private: no hopper or pipe capability is exposed at this stage.
    ItemStackHandler inventory() {
        return inventory;
    }

    public int waterAmount() {
        return water.getFluidAmount();
    }

    /** Fill a whole vanilla water bucket, or leave the tank unchanged. */
    boolean fillWaterBucket() {
        if (level == null || level.isClientSide) {
            return false;
        }
        FluidStack bucket = new FluidStack(Fluids.WATER, FluidType.BUCKET_VOLUME);
        if (water.fill(bucket, FluidAction.SIMULATE) != FluidType.BUCKET_VOLUME) {
            return false;
        }
        return water.fill(bucket, FluidAction.EXECUTE) == FluidType.BUCKET_VOLUME;
    }

    /** Drain a whole amount, or leave the tank unchanged. */
    boolean drainWater(int amount, boolean simulate) {
        if (level == null || level.isClientSide || amount <= 0) {
            return false;
        }
        FluidStack available = water.drain(amount, FluidAction.SIMULATE);
        if (available.getAmount() != amount) {
            return false;
        }
        if (!simulate) {
            water.drain(amount, FluidAction.EXECUTE);
        }
        return true;
    }

    GuildAlchemyCrafting.Status craftingStatus(int recipe, int grade) {
        return GuildAlchemyCrafting.status(GuildAlchemyCrafting.plan(recipe, grade), inventory, waterAmount());
    }

    /** Called on the server thread. One accepted request creates exactly one potion. */
    boolean craft(int recipe, int grade) {
        if (level == null || level.isClientSide || isRemoved() || crafting
                || level.getBlockEntity(worldPosition) != this) return false;
        crafting = true;
        try {
            GuildAlchemyCrafting.Plan plan = GuildAlchemyCrafting.plan(recipe, grade);
            if (GuildAlchemyCrafting.status(plan, inventory, waterAmount()) != GuildAlchemyCrafting.Status.READY) {
                return false;
            }
            ItemStack[] remaining = new ItemStack[plan.ingredients().length];
            for (int i = 0; i < remaining.length; i++) {
                remaining[i] = inventory.getStackInSlot(i).copy();
                remaining[i].shrink(plan.ingredients()[i].getCount());
            }
            ItemStack existing = inventory.getStackInSlot(OUTPUT_SLOT);
            ItemStack result = existing.isEmpty() ? plan.potion().copy() : existing.copyWithCount(existing.getCount() + 1);
            if (!drainWater(plan.water(), false)) return false;
            for (int i = 0; i < remaining.length; i++) inventory.setStackInSlot(i, remaining[i]);
            inventory.setStackInSlot(OUTPUT_SLOT, result);
            // Publish only after water, all ingredients and the output have been committed.
            publishWaterChange();
            return true;
        } finally {
            crafting = false;
        }
    }

    void dropInventory() {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int slot = 0; slot < SLOT_COUNT; slot++) {
            while (!inventory.getStackInSlot(slot).isEmpty()) {
                ItemStack stack = inventory.extractItem(slot, Integer.MAX_VALUE, false);
                if (stack.isEmpty()) {
                    break;
                }
                Containers.dropItemStack(level, worldPosition.getX(), worldPosition.getY(), worldPosition.getZ(), stack);
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put(INVENTORY_TAG, inventory.serializeNBT(registries));
        tag.putInt(WATER_TAG, waterAmount());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        CompoundTag inventoryTag = tag.getCompound(INVENTORY_TAG).copy();
        // A malformed Size field must never expand the six-slot workbench.
        inventoryTag.putInt("Size", SLOT_COUNT);
        inventory.deserializeNBT(registries, inventoryTag);
        loadWater(tag);
    }

    private void loadWater(CompoundTag tag) {
        int amount = Mth.clamp(tag.getInt(WATER_TAG), 0, WATER_CAPACITY);
        water.setFluid(amount == 0 ? FluidStack.EMPTY : new FluidStack(Fluids.WATER, amount));
    }

    // Only water is broadcast to nearby clients; menu viewers receive slot updates separately.
    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        tag.putInt(WATER_TAG, waterAmount());
        return tag;
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public void handleUpdateTag(CompoundTag tag, HolderLookup.Provider registries) {
        loadWater(tag);
    }

    @Override
    public void onDataPacket(Connection connection, ClientboundBlockEntityDataPacket packet,
            HolderLookup.Provider registries) {
        handleUpdateTag(packet.getTag(), registries);
    }
}
